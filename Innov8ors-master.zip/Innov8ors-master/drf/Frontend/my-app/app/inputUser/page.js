import React from 'react'
import Dropzone from '@/components/drop'

const inputUser = () => {
  return (
    <div><Dropzone /></div>
  )
}

export default inputUser