Team Name:- Innov8ors

Member 1 - Gautam Singal
Member 2 - Nalin Gupta
Member 3 - Mehul Bansal
Member 4 - Raghav Aggarwal
Member 5 - Vipin Bansal

Problem Statement- Scenario - 1: Data Analysis
